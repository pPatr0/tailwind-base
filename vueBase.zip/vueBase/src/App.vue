<script setup>

</script>


<template>
  <header>
  </header>

<RouterView>

</RouterView>

</template>


<style scoped>

</style>